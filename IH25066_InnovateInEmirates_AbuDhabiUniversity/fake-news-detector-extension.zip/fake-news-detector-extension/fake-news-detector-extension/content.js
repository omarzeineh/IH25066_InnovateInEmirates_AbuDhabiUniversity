// content.js

// Import Readability.js (assuming it's loaded as a web_accessible_resource or similar)
// For simplicity in a hackathon, we might directly include its source or use a CDN in a real project.
// For now, we'll assume a basic DOM parsing approach for dynamic content and a simpler readability for static.

// Function to generate a unique ID for each content block
function generateUniqueId() {
  console.log("FND: Initializing content script.");
  return 'fnd-' + Math.random().toString(36).substr(2, 9);
}

// Store references to processed elements to avoid re-processing and for UI updates
const processedElements = new Map(); // Map<HTMLElement, {id: string, originalContent: string}>

// Function to extract text content from an element
function extractText(element) {
  // Prioritize text content, filter out script/style tags, and excessive whitespace
  let text = element.textContent || '';
  text = text.replace(/\s+/g, ' ').trim();
  return text.length > 50 ? text : ''; // Only consider substantial text blocks
}

// Function to extract image data from an element
function extractImage(element) {
  let imgElement = null;
  if (element.tagName === 'IMG') {
    imgElement = element;
  } else {
    imgElement = element.querySelector('img');
  }

  if (imgElement && imgElement.src && imgElement.src.startsWith('http')) {
    console.log("FND: Extracted image", { src: imgElement.src, alt: imgElement.alt || '' });
    return { src: imgElement.src, alt: imgElement.alt || '' };
  }
  return null;
}

// Function to create and inject the initial GRAY loading dot
function injectLoadingDot(targetElement, contentBlockId) {
  if (!targetElement || targetElement.dataset.fndProcessed === 'true') {
    return; // Avoid re-injecting
  }

  // Do not inject into non-visible elements
  if (targetElement.offsetWidth === 0 && targetElement.offsetHeight === 0) {
    return;
  }

  const dot = document.createElement('div');
  dot.className = 'fnd-indicator fnd-gray';
  dot.dataset.fndId = contentBlockId;
  dot.innerHTML = '<div class="fnd-dot"></div>';

  // Ensure the target has a positioning context
  targetElement.style.position = 'relative';

  // Explicitly set top and right for the dot
  dot.style.top = '5px';
  dot.style.right = '5px';

  targetElement.appendChild(dot);
  // Mark the container of the dot as processed, not the dot itself, to avoid nested dots.
  const container = targetElement.closest('.post, article');
  if (container) {
      container.setAttribute('data-fnd-processed', 'true');
  }

  console.log(`FND: Injected gray dot for block ${contentBlockId} on element`, targetElement);
  return dot;
}

// Function to update the dot's color and add hover functionality
function updateDot(contentBlockId, confidenceLevel, sources, headline, summary) {
  const dotElement = document.querySelector(`.fnd-indicator[data-fnd-id="${contentBlockId}"]`);
  if (!dotElement) {
    console.warn(`FND: Dot element not found for block ID: ${contentBlockId}`);
    return;
  }

  dotElement.classList.remove('fnd-gray', 'fnd-green', 'fnd-orange', 'fnd-red');
  dotElement.classList.add(`fnd-${confidenceLevel.toLowerCase()}`);
  console.log(`FND: Dot for block ${contentBlockId} updated to color: ${confidenceLevel.toLowerCase()}`);

  // Create hover popup
  const popup = document.createElement('div');
  popup.className = 'fnd-popup';
  let popupContent = `<strong>${headline || 'News Analysis'}</strong><br>`;
  popupContent += `<small>${summary || 'No summary available.'}</small><hr>`;

  if (sources && sources.length > 0) {
    popupContent += '<ul>';
    sources.slice(0, 3).forEach(source => {
      popupContent += `<li><a href="#" data-url="${source.url}">${source.name}</a></li>`;
    });
    popupContent += '</ul>';
  } else {
    popupContent += '<p>nothing found</p>';
  }
  popup.innerHTML = popupContent;

  // Append popup to the dot and handle hover
  dotElement.appendChild(popup);

  let hidePopupTimer;

  dotElement.addEventListener('mouseenter', () => {
    clearTimeout(hidePopupTimer);
    popup.style.display = 'block';
  });

  dotElement.addEventListener('mouseleave', () => {
    hidePopupTimer = setTimeout(() => {
      popup.style.display = 'none';
    }, 200);
  });

  popup.addEventListener('mouseenter', () => {
    clearTimeout(hidePopupTimer);
  });

  popup.addEventListener('mouseleave', () => {
    hidePopupTimer = setTimeout(() => {
      popup.style.display = 'none';
    }, 200);
  });

  // Handle click on source links within the popup
  popup.addEventListener('click', (event) => {
    if (event.target.tagName === 'A' && event.target.dataset.url) {
      event.preventDefault();
      console.log(`FND: Opening new tab for URL: ${event.target.dataset.url}`);
      chrome.runtime.sendMessage({ type: 'OPEN_TAB', url: event.target.dataset.url });
    }
  });
  console.log(`FND: Updated dot for block ${contentBlockId} to ${confidenceLevel}.`);
}

// Main function to scan and send content
async function scanAndSendContent() {
  const contentBlocks = [];
  const pageUrl = window.location.href;

  // More specific selectors for news articles and social media posts
  const POTENTIAL_CONTAINER_SELECTORS = [
    'article',
    '.post', '.feed-item', '.tweet',
    'div[role="article"]', 'div[data-testid="tweet"]'
  ].join(',');

  const containers = document.querySelectorAll(POTENTIAL_CONTAINER_SELECTORS);

  containers.forEach(container => {
    // Check if this container or any of its significant children have already been processed
    if (container.hasAttribute('data-fnd-processed')) {
        return;
    }

    let combinedText = [];
    let imageUrl = '';

    // Extract text from child elements
    container.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, blockquote, [role="text"]').forEach(textElement => {
      const text = extractText(textElement);
      if (text) combinedText.push(text);
    });

    // Extract image data from child elements
    const imgElement = container.querySelector('img');
    if (imgElement) {
      const image = extractImage(imgElement);
      if (image) {
        imageUrl = image.src;
        if (image.alt) combinedText.push(image.alt);
      }
    }

    const finalCombinedText = combinedText.join(' ').trim();

    if (finalCombinedText || imageUrl) {
      const blockId = generateUniqueId();
      processedElements.set(container, { id: blockId, originalContent: finalCombinedText || imageUrl });

      // Inject dot onto the header if it exists, otherwise the container
      const injectionTarget = container.querySelector('.post-header, header') || container;
      injectLoadingDot(injectionTarget, blockId);

      contentBlocks.push({
        id: blockId,
        type: finalCombinedText ? 'text' : 'image',
        text_content: finalCombinedText,
        image_url: imageUrl
      });
    }
  });

  if (contentBlocks.length > 0) {
    console.log(`FND: Sending ${contentBlocks.length} content blocks for analysis.`, contentBlocks);
    const tabId = await getCurrentTabId();
    chrome.runtime.sendMessage({ type: 'ANALYZE_CONTENT', payload: { contentBlocks, tabId } });
  } else {
    console.log("FND: No new content blocks to send for analysis.");
  }
}

// Get current tab ID (needed for sending messages back to specific tab)
async function getCurrentTabId() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'GET_CURRENT_TAB_ID' }, (response) => {
      resolve(response.id);
    });
  });
}

// Listen for analysis results from the background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'ANALYSIS_RESULT') {
    console.log("FND: Received analysis results:", request.payload.analysisResults);
    const { analysisResults } = request.payload;
    analysisResults.forEach(result => {
      updateDot(result.id, result.confidence_level, result.sources, result.headline, result.summary);
    });
    sendResponse({ status: 'UI updated' });
    return true;
  } else {
    console.log("FND: Received unknown message type in content script:", request.type);
  }
});

// Initial scan on page load
scanAndSendContent();
console.log("FND: Initial scan triggered.");

// Use MutationObserver for dynamic content (e.g., infinite scrolling on social media)
const observer = new MutationObserver((mutationsList) => {
  for (const mutation of mutationsList) {
    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
      // Debounce the scan to avoid excessive processing on rapid DOM changes
      clearTimeout(window.fndScanTimeout);
      window.fndScanTimeout = setTimeout(() => {
        console.log("FND: MutationObserver triggered debounced scan.");
        scanAndSendContent();
      }, 1000); // Increased debounce time for stability
      break; // Process once per mutation batch
    }
  }
});

// Start observing the document body for changes
observer.observe(document.documentElement, { childList: true, subtree: true }); // Observe the entire document for broader changes