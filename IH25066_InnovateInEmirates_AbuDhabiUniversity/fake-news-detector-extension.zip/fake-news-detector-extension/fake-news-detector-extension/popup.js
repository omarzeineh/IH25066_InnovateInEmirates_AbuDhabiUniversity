// popup.js

document.addEventListener("DOMContentLoaded", () => {
  const statusElement = document.getElementById("status");
  // You can add more complex logic here to display overall status or settings
  statusElement.textContent = "Ready";
});

