import { GoogleGenerativeAI } from './lib/google-genai.mjs';

// background.js

const GEMINI_API_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; // Replaced with our actual Gemini API key
const GOOGLE_SEARCH_API_KEY = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; // Replaced with our actual Google Search API key

const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-lite" });

function getNewsClassificationPrompt(text) {
  return `
  You are an expert news content classifier. Your task is to analyze the provided text and determine if it constitutes a news article.
  Your response MUST be a single, valid JSON object and nothing else. Do not include any text before or after the JSON object.

  Input Text: """${text}"""
  if the text is informative, fact-based, and reports on recent events or developments, classify it as 'NEWS'.
  words like "announced", "breaking", "report", "according to sources", "latest", or references to specific dates, events or quotes from officials are strong indicators of news content.
  Otherwise, classify it as 'NOT NEWS'.
  Based on your analysis, classify the text as 'NEWS' or 'NOT NEWS'.
  - If 'NEWS', extract the main headline, 3 key phrases, and a concise summary (max 3 sentences).
  - If 'NOT NEWS', provide a brief reason.

  The JSON object must have the following structure:
  For NEWS:
  {
    "classification": "NEWS",
    "headline": "Example Headline",
    "key_phrases": ["phrase1", "phrase2", "phrase3"],
    "summary": "Example summary."
  }
  For NOT NEWS:
  {
    "classification": "NOT NEWS",
    "reason": "This is not a news article because..."
  }
  `;
}

function getSearchQueryGenerationPrompt(headline, key_phrases, summary) {
  return `
  You are an expert search query generator. Based on the provided news headline, key phrases, and summary, generate exactly 3 effective search queries to find corroborating news articles.
  Your response MUST be a single, valid JSON object and nothing else. Do not include any text before or after the JSON object.

  Input Headline: """${headline}"""
  Input Key Phrases: ${key_phrases}
  Input Summary: """${summary}"""

  The JSON object must have the following structure:
  {
    "search_queries": ["query1", "query2", "query3"]
  }
  `;
}

function getRelativityDeciderPrompt(headline, summary, search_results) {
  return `
  You are an expert news fact-checker. Evaluate the list of search results against the original news item.
  Your response MUST be a single, valid JSON object and nothing else. Do not include any text before or after the JSON object.

  Assign a confidence level:
  - "Green": If reputable sources clearly corroborate the main claims.
  - "Orange": If there are some similarities but also contradictions make sure to use this even if the contradictions are really small, be very strict, or if the sources are not highly reputable.
  - "Red": If there is no support from trusted sources or a direct conflict.

  Select the top 3 most relevant and credible news sources.

  Original News Headline: """${headline}"""
  Original News Summary: """${summary}"""
  Search Results (JSON Array): ${search_results}

  The JSON object must have the following structure:
  {
    "confidence_level": "Green",
    "top_sources": [
      { "name": "Example Source Name", "url": "https://example.com/news", "reason": "This source directly corroborates the event." }
    ]
  }
  `;
}

chrome.runtime.onInstalled.addListener(() => {
  console.log('FND: Service Worker Installed');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'GET_CURRENT_TAB_ID':
      if (sender.tab) {
        sendResponse({ id: sender.tab.id });
      } else {
        sendResponse({ id: null });
      }
      break;
    case 'ANALYZE_CONTENT':
      analyzeContent(request.payload.contentBlocks).then(analysisResults => {
        if (request.payload.tabId) {
          chrome.tabs.sendMessage(request.payload.tabId, {
            type: 'ANALYSIS_RESULT',
            payload: { analysisResults }
          });
        }
        sendResponse({ status: "Analysis complete" });
      });
      return true; // Indicate an asynchronous response.
    case 'OPEN_TAB':
      chrome.tabs.create({ url: request.url });
      sendResponse({ status: "Tab opened" });
      break;
    default:
      console.log('FND: Received unknown message type in Service Worker:', request.type);
      sendResponse({ status: "Unknown message type" });
      break;
  }
  // Return false or undefined for synchronous cases
  return false;
});

async function analyzeContent(contentBlocks) {
  const analysisPromises = contentBlocks.map(async (block) => {
    try {
      console.log(`FND: [${block.id}] STAGE 1: Starting analysis for block.`);

      // 1. Classify as news or not
      const classificationPrompt = getNewsClassificationPrompt(block.text_content);
      const classificationResult = await callGemini(classificationPrompt);
      console.log(`FND: [${block.id}] STAGE 2: Classification complete.`, classificationResult);

      if (classificationResult.classification === 'NEWS') {
        // 2. Generate search queries
        const searchQueryGenerationPrompt = getSearchQueryGenerationPrompt(
          classificationResult.headline,
          JSON.stringify(classificationResult.key_phrases),
          classificationResult.summary
        );
        const searchQueryGenerationResult = await callGemini(searchQueryGenerationPrompt);
        const searchQueries = searchQueryGenerationResult.search_queries;
        console.log(`FND: [${block.id}] STAGE 3: Search query generation complete.`, searchQueries);

        // 3. Search with Google Search API
        const searchResults = await callGoogleSearch(searchQueries, block.id);
        console.log(`FND: [${block.id}] STAGE 4: Google Search complete. Found ${searchResults.length} results.`);

        // 4. Analyze search results with Relativity Decider
        const relativityDeciderPrompt = getRelativityDeciderPrompt(
          classificationResult.headline,
          classificationResult.summary,
          JSON.stringify(searchResults)
        );
        const relativityDeciderResult = await callGemini(relativityDeciderPrompt);
        console.log(`FND: [${block.id}] STAGE 5: Relativity check complete.`, relativityDeciderResult);

        return {
          id: block.id,
          confidence_level: relativityDeciderResult.confidence_level,
          sources: relativityDeciderResult.top_sources,
          headline: classificationResult.headline,
          summary: classificationResult.summary,
        };
      } else {
        console.log(`FND: [${block.id}] SKIPPED: Classified as NOT NEWS.`);
        return null; // Not news, no result needed
      }
    } catch (error) {
      console.error(`FND: [${block.id}] Error during analysis pipeline:`, error);
      return {
        id: block.id,
        confidence_level: 'red',
        sources: [],
        headline: 'Analysis Failed',
        summary: 'Could not analyze this content. See the extension service worker logs for details.'
      };
    }
  });

  const results = await Promise.all(analysisPromises);
  return results.filter(result => result !== null);
}

async function callGemini(prompt) {
    try {
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();
        if (!text) {
            throw new Error("Received empty response from Gemini API");
        }
        // Find the start and end of the JSON object
        const startIndex = text.indexOf('{');
        const endIndex = text.lastIndexOf('}');
        if (startIndex === -1 || endIndex === -1) {
            throw new Error("No valid JSON object found in Gemini response");
        }
        const jsonString = text.substring(startIndex, endIndex + 1);
        return JSON.parse(jsonString);
    } catch (error) {
        console.error('FND: Error calling Gemini API:', error);
        throw new Error('Gemini API request failed');
    }
}

async function callGoogleSearch(queries, blockId, retries = 3, delay = 2000) {
  const searchResults = [];
  for (const query of queries) {
    for (let i = 0; i < retries; i++) {
      try {
        const response = await fetch(`https://www.googleapis.com/customsearch/v1?key=${GOOGLE_SEARCH_API_KEY}&cx=3249a750fcf7c4272&q=${encodeURIComponent(query)}`);
        if (response.status === 429) {
          throw new Error('RateLimit');
        }
        if (!response.ok) {
          console.error(`FND: [${blockId}] Google Search API request failed with status ${response.status}`);
          continue; // Try next query
        }
        const data = await response.json();
        if (data.items) {
          searchResults.push(...data.items.map(item => ({
            title: item.title,
            snippet: item.snippet,
            url: item.link,
          })));
        }
        break; // Success, break retry loop
      } catch (error) {
        if (error.message === 'RateLimit' && i < retries - 1) {
          console.warn(`FND: [${blockId}] Google Search API rate limit hit. Retrying in ${delay / 1000}s...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          delay *= 2; // Exponential backoff
        } else {
          console.error(`FND: [${blockId}] Google Search API request failed after retries or for other reasons.`, error);
          // Don't rethrow, just move to the next query
        }
      }
    }
  }
  return searchResults;
}

console.log('FND: Service Worker script loaded.');
